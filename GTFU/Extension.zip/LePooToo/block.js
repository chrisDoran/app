
while (true) {
	console.log("LePoo");
}